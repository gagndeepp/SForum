package com.sforum.util;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;

import com.sforum.model.Admin;
import com.sforum.model.Answer;
import com.sforum.model.Employee;
import com.sforum.model.Post;
import com.sforum.service.ForumService;

public final class Utils {

	private static final int ONE = 1;
	private static final int TWO = 2;
	private static final int THREE = 3;
	private static final int FOUR = 4;
	private static final int FIVE = 5;
	private static final int SIX = 6;
	private static final Logger LOGGER = Logger.getLogger("DeleteAnswerController");
	private static Session session;

	@Autowired
	ForumService forumService;

	@Autowired
	SessionFactory sessionFactory;

	private static void setupHibernate() {
		Utils utilss = new Utils();
		session = utilss.sessionFactory.openSession();
	}

	private Utils() {

	}

	public static Date getCurrDateTime() {
		Date now = new Date();
		return now;
	}

	public static String getCurrentDateTime() {
		java.util.Date dt = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(dt);
	}

	public static Integer parseStringToInt(String number) {
		Integer returnVal = 0;
		try {
			returnVal = Integer.parseInt(number.trim());
		} catch (NumberFormatException e) {
			LOGGER.error(e);
		}
		return returnVal;
	}

	public static Employee getEmployeeFromId(int empId) {
		setupHibernate();
		Transaction transaction = session.beginTransaction();

		Employee employee = session.get(Employee.class, empId);
		// Employee employee = null;
		// Connection connection = ConnectionUtil.getConnection();
		// try (PreparedStatement stmt = connection.prepareStatement("select *
		// from employee where emp_id = ?")) {
		// stmt.setInt(1, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// if (rs.next()) {
		// employee = new Employee(rs.getInt(ONE), rs.getString(TWO),
		// rs.getString(THREE), rs.getString(FOUR),
		// rs.getString(FIVE), rs.getString(SIX));
		// } else {
		// LOGGER.error("Employee not Present for the specified empId");
		// }
		// }
		//
		// } catch (SQLException e) {
		// LOGGER.error(e);
		// }
		transaction.commit();
		session.close();
		return employee;
	}

	public static Admin getAdminFromId(int adminId) {
		setupHibernate();
		Transaction transaction = session.beginTransaction();
		Admin admin = session.get(Admin.class, adminId);
		// Employee employee = null;
		// Connection connection = ConnectionUtil.getConnection();
		// try (PreparedStatement stmt = connection.prepareStatement("select *
		// from employee where emp_id = ?")) {
		// stmt.setInt(1, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// if (rs.next()) {
		// employee = new Employee(rs.getInt(ONE), rs.getString(TWO),
		// rs.getString(THREE), rs.getString(FOUR),
		// rs.getString(FIVE), rs.getString(SIX));
		// } else {
		// LOGGER.error("Employee not Present for the specified empId");
		// }
		// }
		//
		// } catch (SQLException e) {
		// LOGGER.error(e);
		// }
		transaction.commit();
		session.close();
		return admin;
	}

	public static Post getPostFromId(int postId) {
		setupHibernate();
		Transaction transaction = session.beginTransaction();
		Post post = session.get(Post.class, postId);
		// Employee employee = null;
		// Connection connection = ConnectionUtil.getConnection();
		// try (PreparedStatement stmt = connection.prepareStatement("select *
		// from employee where emp_id = ?")) {
		// stmt.setInt(1, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// if (rs.next()) {
		// employee = new Employee(rs.getInt(ONE), rs.getString(TWO),
		// rs.getString(THREE), rs.getString(FOUR),
		// rs.getString(FIVE), rs.getString(SIX));
		// } else {
		// LOGGER.error("Employee not Present for the specified empId");
		// }
		// }
		//
		// } catch (SQLException e) {
		// LOGGER.error(e);
		// }
		transaction.commit();
		session.close();
		return post;

	}

	public static Answer getAnswerFromId(int answerId) {
		setupHibernate();
		Transaction transaction = session.beginTransaction();
		Answer answer = session.get(Answer.class, answerId);
		// Employee employee = null;
		// Connection connection = ConnectionUtil.getConnection();
		// try (PreparedStatement stmt = connection.prepareStatement("select *
		// from employee where emp_id = ?")) {
		// stmt.setInt(1, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// if (rs.next()) {
		// employee = new Employee(rs.getInt(ONE), rs.getString(TWO),
		// rs.getString(THREE), rs.getString(FOUR),
		// rs.getString(FIVE), rs.getString(SIX));
		// } else {
		// LOGGER.error("Employee not Present for the specified empId");
		// }
		// }
		//
		// } catch (SQLException e) {
		// LOGGER.error(e);
		// }
		transaction.commit();
		session.close();
		return answer;
	}

	// @SuppressWarnings("deprecation")
	// public static List<Post> fetchPostByDate() {
	// setupHibernate();
	//
	// }

}
