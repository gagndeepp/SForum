package com.sforum.dao;

import java.util.List;

import com.sforum.model.Admin;
import com.sforum.model.Answer;
import com.sforum.model.Employee;
import com.sforum.model.Post;

public interface ForumDao {

	public int EmpLoginCheck(Employee employee);

	public int addEmployee(Employee employee);

	public List<Post> fetchPostByDate();

	// public List<Post> fetchPostByDate();

	// int doEmpLoginCheck(int empId, String password);
	//
	int doAdminLoginCheck(Admin admin);

	public Post getPostFromId(int postId);
	
	public Employee getEmployeeFromId(int empId);
	//
	// int registerAdmin(Admin admin);
	//
	// int registerEmployee(Employee employee);
	//
	int createPost(Post post);

	//
	int editPost(Post post);

	//
	int addAnswer(Answer answer);

	//
	int editAnswer(Answer answer);

	//
	// List<Post> fetchPostByDate();
	//
	int deletePost(int postId);

	//
	int deleteAnswer(int answerId);

	//
	List<Answer> fetchAnswers(int empId);

	//
	List<Post> fetchPosts(int empId);

	//
	List<Answer> fetchPostAnswers(int postId);

	//
	List<Post> searchPosts(String searchQuery);

	//
	List<Answer> searchAnswer(String searchQuery);
}
