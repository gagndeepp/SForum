package com.sforum.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.sforum.model.Answer;
import com.sforum.model.Employee;
import com.sforum.model.Post;
import com.sforum.service.ForumService;

@Controller
@Scope("session")
@SessionAttributes({ "emp", "user_name" })
public class ForumController {

	@Autowired
	ForumService forumService;
	// @Autowired
	private Employee employee;

	/*
	 * @RequestMapping("/loginPage") public String loginPage(Model model) { return
	 * "login"; }
	 */
	@RequestMapping("/editAnswerPage")
	public String editAnswerPage(@ModelAttribute("editAnswer") Answer currentAnswer, Model model) {
		System.out.println("Edit AnswerPAGE value updated or not???" + currentAnswer.toString());
		model.addAttribute("currentAnswer", currentAnswer);
		return "editAnswer";
	}

	@RequestMapping("/editAnswer")
	public String editAnswer(@ModelAttribute("editAnswer") Answer currentAnswer, Model model) {
		System.out.println("Edit Answer value updated or not???" + currentAnswer.toString());
		return "redirect:/viewEmpAnswers";
	}

	@RequestMapping("/editQuestion")
	public String editQuestion(@ModelAttribute("post") Post post) {
		return "editQuesstion";
	}

	@RequestMapping("/viewPostAnswers")
	public String viewPostAnswers(@ModelAttribute("answer") Answer answer,
			@RequestParam("currentPostId") Integer currentPId, Model model) {
		// Logger logger = Logger.getLogger("PostController");
		// response.setContentType("text/html");
		// String postId = request.getParameter("currentPostId");
		// logger.info("Post id is 500 range?? " + postId);
		// ForumService service = new ForumService();
		// Post post = Utils.getPostFromId(Utils.parseStringToInt(postId));
		// logger.info("Current Post is must be 500 range" + post.toString());
		// request.setAttribute("selectedpost", post);
		// List<Answer> answerList = service.fetchPostAnswers(post.getPostId());
		// request.setAttribute("answers", answerList);
		// try {
		// request.getRequestDispatcher("/jsp/postdetail.jsp").forward(request,
		// response);
		// } catch (Exception e) {
		// logger.error(e);
		// }

		// System.out.println("|||||||||||||||||currentPostIdinsideViewPosstAnswerssssssss"
		// + Integer.parseInt(request.getParameter("currentPostId")));
		Post p = forumService.getPostFromId(currentPId);
		List<Answer> postAnswers = forumService.fetchPostAnswers(currentPId);
		model.addAttribute("selectedpost", p);
		model.addAttribute("answers", postAnswers);
		// System.out.println(
		// "ViewEmpAnswers>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + p.toString() + "|||||||"
		// + postAnswers.size());
		return "postdetail";
	}

	@RequestMapping("/addPostAnswer")
	public String addPostAnswer(@ModelAttribute("answer") Answer answer) {
		// System.out.println("addPostAnswer> >}}}}}ANSWERFROMFRONT}}}}}}}}}" +
		// answer.toString());
		// Post p = forumService.getPostFromId(currentPId);
		answer.setEmployeeA(employee);
		// answer.setPostA(p);
		// System.out.println("addPostAnswer>?>>>>}}}}}}}RESTALLDATA}}}}}}}" +
		// p.toString() + "}}}}}"
		// + request.getSession().getAttribute("emp").toString() + "\n\n" +
		// answer.toString());
		// System.out.println("Add AANSWRESSDS >> " + answer + " .... " );
		Post p = forumService.getPostFromId(Integer.parseInt(answer.getPostA().getPostDesc()));
		System.out.println("Post Address wagerah" + answer.getPostA());
		answer.setPostA(p);
		forumService.addAnswer(answer);
		// System.out.println("AddPostAnswer >> " + answer.getAnswerDesc() + " .. " +
		// answer.getPostA().getPostDesc().toString());
		// request.setAttribute("currentPostId", p.getPostId());

		return "redirect:/";
	}

	@RequestMapping("/viewEmpPosts")
	public String viewEmpPosts(Model model) {
		System.out.println("ViewEmpPosts>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		List<Post> currentEmpPosts = forumService.fetchPosts(employee.getEmpId());
		model.addAttribute("searchResult", currentEmpPosts);
		return "viewQuestion";
	}

	@RequestMapping("/searchPosts")
	public String searchPosts(Model model, @RequestParam("searchquery") String searchQuery) {
		System.out.println("Search><<<><><<><>>><>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		List<Post> searchResult = forumService.searchPosts(searchQuery);
		// request.setAttribute("searchResult", searchResult);
		model.addAttribute("searchResult", searchResult);
		return "search";
	}

	@RequestMapping("/viewEmpAnswers")
	public String viewEmpAnswers(@ModelAttribute("editAnswer")Model model) {
		System.out.println("ViewEmpAnswers>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		List<Answer> currentEmpAnswers = forumService.fetchAnswers(employee.getEmpId());
		model.addAttribute("answers", currentEmpAnswers);
		return "viewAnswer";
	}

	@RequestMapping("/askQuestionPage")
	public String askQuestionController(@ModelAttribute("post") Post post) {
		System.out.println("AskQuesstionPage>>>>>>>>>>>>>>>>>>>>>>>");
		return "askquestion";
	}

	@RequestMapping("/addQuestion")
	public String addQuestionController(@ModelAttribute("post") Post post, Model model) {
		System.out.println("AddQuestionController>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		/*
		 * post.setEmployeeP((Employee) request.getSession().getAttribute("emp"));
		 * System.out.println("CreatePostaddQuestionController" + " ///// " +
		 * post.toString()); forumService.createPost(post);
		 */
		post.setEmployeeP(employee);
		// model.addAttribute("postdesc", post.getPostDesc());
		forumService.createPost(post);
		return "redirect:/";
	}

	@RequestMapping("/")
	public String homeController(Model model) {

		// Logger logger = Logger.getLogger("HomeController");
		// response.setContentType("text/html");
		/// * ForumService service = new ForumService();*/
		// List<Post> resultSet = Utils.fetchPostByDate();
		// System.out.println();
		// System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
		// + resultSet.size());
		// request.setAttribute("homeResult", resultSet);
		// try {
		// request.getRequestDispatcher("/index.jsp").forward(request, response);
		// } catch (Exception e) {
		// e.printStackTrace();
		// logger.error(e.getStackTrace());
		// }
		// System.out.println("HomeControllerFORUMOBJECTEMPLOYEE >>" + employee);
		// if (employee == null) {
		// System.out.println("EmplyeeNull????");
		// return "redirect:/login";
		// }
		System.out.println("Home>>>>>>>>>>>>>>>>>>>>");
		if (employee == null) {
			model.addAttribute("emp", new Employee(0));
		}
		if (employee != null) {
			System.out.println("EmployeeNotNull");
			List<Post> resultSet = forumService.fetchPostByDate();
			System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" + resultSet.size());
			model.addAttribute("homeResult", resultSet);
		}
		return "index";
	}

	@RequestMapping("/logoutController")

	public String logoutController(Model model) {
		System.out.println("Logout?>>>>>>>>>>>>>>>>>>>>>>>>><><><>><><><><><>><><>,");
		model.addAttribute("emp", new Employee(0));
		return "redirect:/";
	}

	@RequestMapping("/login")
	public String loginController(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("employee") Employee employee) {
		System.out.println("Login>>>>>>>>>>>>>>>>>>>>");
		return "login";
	}

	@RequestMapping("/checkLogin")
	public String checkEmpLogin(@ModelAttribute("employee") Employee loginEmp, Model model) {

		int check = forumService.EmpLoginCheck(loginEmp);
		if (check == 1) {
			Employee dbEmp = forumService.getEmployeeFromId(loginEmp.getEmpId());
			this.employee = dbEmp;
			// System.out.println("Employee Object in CheckEmpLogin >> " + employee);
			// session.set
			System.out.println(employee.toString() + " <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<|||");
			model.addAttribute("emp", employee);
			model.addAttribute("user_name", employee.getEmpName());
			// httpSession.setAttribute("emp", dbEmp);
			// httpSession.setAttribute("user_name", dbEmp.getEmpName());
			// request.getSession().setAttribute("user_name", employee);
			// request.getSession().setAttribute("emp", dbEmp);
			// request.getSession().setAttribute("empId", employee.getEmpId());
			return "redirect:/";
		} else {
			// request.setAttribute("message", "Login Error");
			return "login";
		}

		// System.out.println("EmployeeLoginCheck" + " >>>>>>>> " + employee);
		// int check = forumService.EmpLoginCheck(employee);
		// Employee dbEmp = forumService.getEmployeeFromId(employee.getEmpId());
		// if (check == 1) {
		// request.getSession().setAttribute("user_name", employee);
		// request.getSession().setAttribute("emp", dbEmp);
		// request.getSession().setAttribute("empId", employee.getEmpId());
		// return "redirect:/";
		// } else {
		// request.setAttribute("message", "Login Error");
		// return "login";
		// }
		// return "redirect:/";
	}

	@RequestMapping("/registerPage")
	public String registerPage(@ModelAttribute("employee") Employee employee) {
		System.out.println("Register>>>>>>>>>>>>>>>>>>>>");
		// model.addAttribute(employee);
		return "signup";
	}

	@RequestMapping("/registerEmployee")
	public String registerController(@ModelAttribute("employee") Employee employee) {
		System.out.println("RegisterEmployeeeeeeeeeeee>>>>>>>>>>>>>>>>>>>>");
		System.out.println(employee);
		forumService.addEmployee(employee);
		return "login";
	}

}
