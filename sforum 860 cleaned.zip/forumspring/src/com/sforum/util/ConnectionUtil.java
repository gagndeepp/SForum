package com.sforum.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public final class ConnectionUtil {

	private ConnectionUtil() {

	}

	public static Connection getConnection() {
		Logger logger = Logger.getLogger("ConnectionUtil");
		Connection connection = null;
		// System.out.println("Why is Class not found 1>>>>>>>>>>> " +
		// com.mysql.jdbc.Driver.class + "\n" + "\n");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// System.out.println("Why is Class not found 2>>>>>>>>>>> " +
			// com.mysql.jdbc.Driver.class + "\n" + "\n");
		} catch (ClassNotFoundException e) {
			// System.out.println("Why is Class not found 3>>>>>>>>>>> " +
			// com.mysql.jdbc.Driver.class + "\n" + e + "\n");
			logger.error(e);
		}
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:4406/vforum", "root", "root");
			logger.info("|||||||||||||||||||||||||||||ConnectionSucessfull");
		} catch (SQLException e) {
			// System.out.println("SQLException is getting raised >>>>>>>>>>> "
			// + "\n" + e + "\n");
			logger.error("SQL error", e);
			logger.info("|||||||||||||||||||||||||||||Connection NOT Sucessfull");
			logger.info(e.getLocalizedMessage());
		}
		// System.out.println("Why is Class not found 4>>>>>>>>>>> " +
		// com.mysql.jdbc.Driver.class + "\n" + "\n");
		return connection;

	}

}
