package com.sforum.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;
import org.springframework.format.annotation.DateTimeFormat;

@Indexed
@Entity
@Table(name = "posttab")
public class Post {

	public Post() {
		super();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int postId;
	@Field(index = Index.YES, analyze = Analyze.YES, store = Store.NO)
	private String postDesc;
	@Temporal(TemporalType.TIMESTAMP)
	private Date postDate;
	// @DateTimeFormat()
	// @Override
	// public String toString() {
	// return "Post [postId=" + postId + ", postDesc=" + postDesc + ", postDate=" +
	// postDate + ", employeeP="
	// + employeeP + ", answers=" + answers + "]";
	// }

	// private int empId;
	@ManyToOne()
	@JoinColumn(name = "empId")
	private Employee employeeP;

	@Override
	public String toString() {
		return postId + "";
	}

	@OneToMany(mappedBy = "postA", orphanRemoval = true, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Answer> answers;

	public Post(String postDesc, Employee employee) {
		super();
		this.postDesc = postDesc;
		this.employeeP = employee;
	}

	public Post(int postId, String postDesc, Date postDate, int empId) {
		super();
		this.postId = postId;
		this.postDesc = postDesc;
		this.postDate = (Date) postDate.clone();
		// this.empId = empId;
	}

	public Post(String postDesc, Date postDate, Employee employee) {
		super();
		this.postDesc = postDesc;
		this.postDate = postDate;
		this.employeeP = employee;
	}

	public Post(String postDesc2) {
		this.postDesc = postDesc2;
	}

	public Post(int postId, String postDesc, int empId) {
		super();
		this.postId = postId;
		this.postDesc = postDesc;
		// this.empId = empId;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getPostDesc() {
		return postDesc;
	}

	public void setPostDesc(String postDesc) {
		this.postDesc = postDesc;
	}

	public Date getPostDate() {
		return postDate;
	}

	public void setPostDate(Date postDate) {
		this.postDate = postDate;
	}

	public Employee getEmployeeP() {
		return employeeP;
	}

	public void setEmployeeP(Employee employeeP) {
		this.employeeP = employeeP;
	}

	public List<Answer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}

	// @Override
	// public String toString() {
	// return "Post [postId=" + postId + ", postDesc=" + postDesc + ", postDate=" +
	// postDate + ", employeeP="
	// + employeeP + ", answers=" + answers + "]";
	// }

	// public Employee getEmployeeObj() {
	// return Utils.getEmployeeFromId(empId);
	// }
	//
	// public int getEmpId() {
	// return empId;
	// }
	//
	// public void setEmpId(int empId) {
	// this.empId = empId;
	// }

}
