package com.sforum.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "employeetab")
//@Component
//@Scope(scopeName = "session", proxyMode = ScopedProxyMode.INTERFACES)
public class Employee implements Serializable {

	/**
	 * 
	 */
	@Id
	private int empId;
	private String empName;
	private String empAlias;
	private String empPassword;
	public Employee(int empId) {
		super();
		this.empId = empId;
	}

	private String empDesignation;
	private String empLocation;
	@OneToMany(mappedBy = "employeeP", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Post> posts;
	@OneToMany(mappedBy = "employeeA", cascade = CascadeType.ALL)
	private List<Answer> answers;

	private static final long serialVersionUID = 1L;

	public Employee(int empId, String empName, String empAlias, String empDesignation, String empLocation,
			String empPassword) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAlias = empAlias;
		this.empPassword = empPassword;
		this.empDesignation = empDesignation;
		this.empLocation = empLocation;
	}

	public Employee() {
		super();
	}

	public Employee(int empId, String empPassword) {
		super();
		this.empId = empId;
		this.empPassword = empPassword;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAlias() {
		return empAlias;
	}

	public void setEmpAlias(String empAlias) {
		this.empAlias = empAlias;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public String getEmpLocation() {
		return empLocation;
	}

	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}

	public List<Post> getPosts() {
		return posts;
	}

	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}

	public List<Answer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}

	@Override
	public String toString() {
		return "\n\nEmployee [empId=" + empId + ", empName=" + empName + ", empAlias=" + empAlias + ", empPassword="
				+ empPassword + ", emp_designation=" + empDesignation + ", emp_location=" + empLocation + "]\n\n";
	}

}
