package com.sforum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sforum.dao.ForumDao;
import com.sforum.model.Admin;
import com.sforum.model.Answer;
import com.sforum.model.Employee;
import com.sforum.model.Post;

@Service
public class ForumServiceImpl implements ForumService{

	@Autowired
	public ForumDao forumDao;

	@Override
	public int EmpLoginCheck(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("InServiceClassEmpLoginCheck>><<<<<>><><><><><><><");
		return forumDao.EmpLoginCheck(employee);
	}

	@Override
	@Transactional
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("InServiceClassAddEmployee>><<<<<>><><><><><><><");
		return forumDao.addEmployee(employee);
	}

	@Override
	public List<Post> fetchPostByDate() {
		// TODO Auto-generated method stub
		return forumDao.fetchPostByDate();
	}

	@Override
	public int doAdminLoginCheck(Admin admin) {
		// TODO Auto-generated method stub
		return forumDao.doAdminLoginCheck(admin);
	}

	@Override
	public int createPost(Post post) {
		// TODO Auto-generated method stub
		return forumDao.createPost(post);
	}

	@Override
	public int editPost(Post post) {
		// TODO Auto-generated method stub
		return forumDao.editPost(post);
	}

	@Override
	public int addAnswer(Answer answer) {
		// TODO Auto-generated method stub
		return forumDao.addAnswer(answer);
	}

	@Override
	public int editAnswer(Answer answer) {
		// TODO Auto-generated method stub
		return forumDao.editAnswer(answer);
	}

	@Override
	public int deletePost(int postId) {
		// TODO Auto-generated method stub
		return forumDao.deletePost(postId);
	}

	@Override
	public int deleteAnswer(int answerId) {
		// TODO Auto-generated method stub
		return forumDao.deleteAnswer(answerId);
	}

	@Override
	public List<Answer> fetchAnswers(int empId) {
		// TODO Auto-generated method stub
		return forumDao.fetchAnswers(empId);
	}

	@Override
	public List<Post> fetchPosts(int empId) {
		// TODO Auto-generated method stub
		return forumDao.fetchPosts(empId);
	}

	@Override
	public List<Answer> fetchPostAnswers(int postId) {
		// TODO Auto-generated method stub
		return forumDao.fetchPostAnswers(postId);
	}

	@Override
	public List<Post> searchPosts(String searchQuery) {
		// TODO Auto-generated method stub
		return forumDao.searchPosts(searchQuery);
	}

	@Override
	public List<Answer> searchAnswer(String searchQuery) {
		// TODO Auto-generated method stub
		return forumDao.searchAnswer(searchQuery);
	}

	@Override
	public Employee getEmployeeFromId(int empId) {
		// TODO Auto-generated method stub
		return forumDao.getEmployeeFromId(empId);
	}

	@Override
	public Post getPostFromId(int postId) {
		// TODO Auto-generated method stub
		return forumDao.getPostFromId(postId);
	}

	@Override
	public Answer getAnswerFromId(int answerId) {
		// TODO Auto-generated method stub
		return forumDao.getAnswerFromId(answerId);
	}

}
