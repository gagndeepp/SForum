package com.sforum.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sforum.model.Admin;
import com.sforum.model.Answer;
import com.sforum.model.Employee;
import com.sforum.model.Post;
import com.sforum.util.Utils;

@Repository
public class ForumDaoImpl implements ForumDao {

	@Autowired
	protected SessionFactory sessionFactory;

	/*
	 * public void setSessionFactory(SessionFactory sessionFactory) {
	 * this.sessionFactory = sessionFactory; }
	 * 
	 * protected Session getSession() { return sessionFactory.openSession(); }
	 */

	@Override
	public int EmpLoginCheck(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("In Check login");
		Session session = sessionFactory.openSession();
		Employee emp = session.load(Employee.class, employee.getEmpId());
		System.out.println(emp.getEmpPassword() + " || " + employee.getEmpPassword());
		if (employee.getEmpPassword().equals(emp.getEmpPassword())) {
			System.out.println("Sucessfullllllllllllllll<<<<<<<<<<<<<");
			session.close();
			return 1;
		} else {
			System.out.println("UNNNNNNNNNSucessfullllllllllllllll<<<<<<<<<<<<<");
			session.close();
			return 0;
		}
	}

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("In Check login");
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(employee);
		transaction.commit();
		session.close();
		return 1;
	}

	@Override
	public List<Post> fetchPostByDate() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		List<Post> posts = session.createCriteria(Post.class).addOrder(Order.desc("postDate")).list();
		transaction.commit();
		session.close();
		return posts;
	}

	@Override
	public int doAdminLoginCheck(Admin admin) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int createPost(Post post) {
		// TODO Auto-generated method stub

		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		post.setPostDate(Utils.getCurrDateTime());
		session.saveOrUpdate(post);

		FullTextSession fullTextSession = Search.getFullTextSession(session);
		try {
			fullTextSession.createIndexer().startAndWait();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int id = 1;
		if (id > 0) {
			transaction.commit();
			session.close();
			return 1;
		} else {
			transaction.commit();
			session.close();
			return 0;
		}

		// return 0;
	}

	@Override
	public int editPost(Post post) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		// post.setPostDate(Utils.getCurrDateTime());
		session.saveOrUpdate(post);

		FullTextSession fullTextSession = Search.getFullTextSession(session);
		try {
			fullTextSession.createIndexer().startAndWait();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int id = 1;
		if (id > 0) {
			transaction.commit();
			session.close();
			return 1;
		} else {
			transaction.commit();
			session.close();
			return 0;
		}
	}

	@Override
	public int addAnswer(Answer answer) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		// Employee e = session.get(Employee.class, empId);
		// Post p = session.get(Post.class, postId);
		// answer.setEmployeeA(e);
		answer.setAnswerDate(Utils.getCurrDateTime());
		// answer.setPostA(p);
		System.out.println("Answer to String inside DAO" + answer.toString());
		int id = (int) session.save(answer);
		if (id > 0) {
			transaction.commit();
			session.close();
			return 1;
		} else {
			transaction.commit();
			session.close();
			return 0;
		}
	}

	@Override
	public int editAnswer(Answer answer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deletePost(int postId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteAnswer(int answerId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Answer> fetchAnswers(int empId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Employee emp = session.load(Employee.class, empId);
		List<Answer> answerLists = session.createCriteria(Answer.class).add(Restrictions.eq("employeeA", emp)).list();
		// Logger logger = Logger.getLogger("FetchAnswerDao");
		// Connection connection = ConnectionUtil.getConnection();
		// ArrayList<Answer> answerLists = new ArrayList<>();
		// try (PreparedStatement stmt = connection
		// .prepareStatement("select * from answer where answer_emp_id = ? order
		// by answer_date desc")) {
		// stmt.setInt(ONE, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// while (rs.next()) {
		// answerLists.add(new Answer(rs.getInt(ONE), rs.getString(TWO),
		// new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR),
		// rs.getInt(FIVE)));
		// }
		// }
		// } catch (SQLException e) {
		// logger.error(e);
		// }
		if (answerLists == null) {
			answerLists = new ArrayList<Answer>();
		}
		transaction.commit();
		session.close();
		return answerLists;
	}

	@Override
	public List<Post> fetchPosts(int empId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Employee emp = session.load(Employee.class, empId);
		List<Post> postList = session.createCriteria(Post.class).add(Restrictions.eq("employeeP", emp)).list();
		if (postList == null) {
			postList = new ArrayList<Post>();
		}
		transaction.commit();
		session.close();
		return postList;
	}

	@Override
	public List<Answer> fetchPostAnswers(int postId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Post p = session.load(Post.class, postId);
		List<Answer> postAnswers = session.createCriteria(Answer.class).add(Restrictions.eq("postA", p)).list();
		if (postAnswers == null) {
			postAnswers = new ArrayList<Answer>();
		}

		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
				+ postAnswers);

		transaction.commit();
		session.close();
		return postAnswers;
	}

	@Override
	public List<Post> searchPosts(String searchQuery) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		FullTextSession fullTextSession = org.hibernate.search.Search.getFullTextSession(session);
		Transaction tx = fullTextSession.beginTransaction();
		QueryBuilder qb = fullTextSession.getSearchFactory().buildQueryBuilder().forEntity(Post.class).get();
		org.apache.lucene.search.Query query = qb.keyword().onField("postDesc").matching(searchQuery).createQuery();
		// wrap Lucene query in a org.hibernate.Query
		org.hibernate.Query hibQuery = fullTextSession.createFullTextQuery(query, Post.class);
		// execute search

		List<Post> result = hibQuery.list();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> SEARCHPOSTS>>>>>>" + searchQuery + " |||| " + result);
		// System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^>>>>>>>>>>>>>>>>>>>>>>>>>"
		// + result.size()
		// + " >>> " + result.get(0).getPostDesc());
		tx.commit();
		session.close();
		return new ArrayList<Post>(result);
	}

	@Override
	public List<Answer> searchAnswer(String searchQuery) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmployeeFromId(int empId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		Employee employee = session.get(Employee.class, empId);
		// Employee employee = null;
		// Connection connection = ConnectionUtil.getConnection();
		// try (PreparedStatement stmt = connection.prepareStatement("select *
		// from employee where emp_id = ?")) {
		// stmt.setInt(1, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// if (rs.next()) {
		// employee = new Employee(rs.getInt(ONE), rs.getString(TWO),
		// rs.getString(THREE), rs.getString(FOUR),
		// rs.getString(FIVE), rs.getString(SIX));
		// } else {
		// LOGGER.error("Employee not Present for the specified empId");
		// }
		// }
		//
		// } catch (SQLException e) {
		// LOGGER.error(e);
		// }
		transaction.commit();
		session.close();
		return employee;
	}

	@Override
	public Post getPostFromId(int postId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Post post = session.get(Post.class, postId);

		// Employee employee = null;
		// Connection connection = ConnectionUtil.getConnection();
		// try (PreparedStatement stmt = connection.prepareStatement("select *
		// from employee where emp_id = ?")) {
		// stmt.setInt(1, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// if (rs.next()) {
		// employee = new Employee(rs.getInt(ONE), rs.getString(TWO),
		// rs.getString(THREE), rs.getString(FOUR),
		// rs.getString(FIVE), rs.getString(SIX));
		// } else {
		// LOGGER.error("Employee not Present for the specified empId");
		// }
		// }
		//
		// } catch (SQLException e) {
		// LOGGER.error(e);
		// }
		transaction.commit();
		session.close();
		return post;
	}

	@Override
	public Answer getAnswerFromId(int answerId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Answer answer = session.get(Answer.class, answerId);
		// Employee employee = null;
		// Connection connection = ConnectionUtil.getConnection();
		// try (PreparedStatement stmt = connection.prepareStatement("select *
		// from employee where emp_id = ?")) {
		// stmt.setInt(1, empId);
		// try (ResultSet rs = stmt.executeQuery()) {
		// if (rs.next()) {
		// employee = new Employee(rs.getInt(ONE), rs.getString(TWO),
		// rs.getString(THREE), rs.getString(FOUR),
		// rs.getString(FIVE), rs.getString(SIX));
		// } else {
		// LOGGER.error("Employee not Present for the specified empId");
		// }
		// }
		//
		// } catch (SQLException e) {
		// LOGGER.error(e);
		// }
		transaction.commit();
		session.close();
		return answer;
	}

}
