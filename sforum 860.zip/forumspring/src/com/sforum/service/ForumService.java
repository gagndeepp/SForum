package com.sforum.service;

import java.util.List;

import com.sforum.model.Admin;
import com.sforum.model.Answer;
import com.sforum.model.Employee;
import com.sforum.model.Post;

public interface ForumService {

	public int EmpLoginCheck(Employee employee);

	public int addEmployee(Employee employee);

	public Answer getAnswerFromId(int answerId);

	public List<Post> fetchPostByDate();

	// int doEmpLoginCheck(int empId, String password);
	//
	int doAdminLoginCheck(Admin admin);

	public Employee getEmployeeFromId(int empId);

	//
	// int registerAdmin(Admin admin);
	//
	// int registerEmployee(Employee employee);
	//
	int createPost(Post post);

	public Post getPostFromId(int postId);

	//
	int editPost(Post post);

	//
	int addAnswer(Answer answer);

	//
	int editAnswer(Answer answer);

	//
	// List<Post> fetchPostByDate();
	//
	int deletePost(int postId);

	//
	int deleteAnswer(int answerId);

	//
	List<Answer> fetchAnswers(int empId);

	//
	List<Post> fetchPosts(int empId);

	//
	List<Answer> fetchPostAnswers(int postId);

	//
	List<Post> searchPosts(String searchQuery);

	//
	List<Answer> searchAnswer(String searchQuery);
}
